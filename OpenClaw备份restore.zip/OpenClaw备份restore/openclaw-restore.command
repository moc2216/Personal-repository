#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import subprocess
import sys
import os


def run_cmd(cmd, desc):
    print(f"\n▶ {desc}")
    print(f"  命令: {cmd}")
    try:
        result = subprocess.run(
            cmd, shell=True,
            stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            text=True, encoding="utf-8", errors="replace",
        )
        if result.returncode == 0:
            print("✅ 成功")
            return True
        else:
            print("❌ 失败")
            print(f"   错误: {result.stderr.strip()}")
            return False
    except Exception as e:
        print(f"❌ 异常: {e}")
        return False


def pick_backup_file():
    """用 macOS 原生文件选择框让用户选择备份文件，返回路径或 None"""
    script = '''
    tell application "System Events"
        activate
    end tell
    set f to choose file with prompt "选择 OpenClaw 备份文件（.tar.gz）" ¬
        of type {"gz", "tar.gz", "public.gzip-archive"} ¬
        default location (path to home folder)
    return POSIX path of f
    '''
    try:
        result = subprocess.run(
            ["osascript", "-e", script],
            stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            text=True, encoding="utf-8"
        )
        path = result.stdout.strip()
        if path:
            return path
    except Exception as e:
        print(f"文件选择框异常: {e}")
    return None


def main():
    print("=" * 55)
    print("  OpenClaw 备份恢复工具")
    print("  停止进程 → 选择备份 → 重置 → 恢复 → 启动")
    print("=" * 55)

    # 先弹文件选择框，再开始执行，避免用户选到一半终端已经跑了一堆输出
    print("\n📂 请在弹出的窗口中选择备份文件...")
    backup_file = pick_backup_file()

    if not backup_file:
        print("❌ 未选择文件，已取消。")
        sys.exit(0)

    if not os.path.exists(backup_file):
        print(f"❌ 文件不存在：{backup_file}")
        sys.exit(1)

    size_kb = os.path.getsize(backup_file) // 1024
    print(f"✅ 已选择：{backup_file}（{size_kb} KB）")

    # 二次确认
    print(f"\n⚠️  即将用此备份恢复 OpenClaw，当前配置将被覆盖。")
    confirm = input("确认继续？输入 y 继续，其他键取消：").strip().lower()
    if confirm != "y":
        print("已取消。")
        sys.exit(0)

    # 1. 停止进程
    print("\n[1/5] 停止 OpenClaw 进程")
    run_cmd("openclaw gateway stop", "停止网关")
    run_cmd("pkill -f openclaw",     "清理残留进程")

    # 2. 全量重置
    print("\n[2/5] 全量重置")
    if not run_cmd("openclaw reset --scope full --yes", "执行重置"):
        sys.exit(1)

    # 3. 恢复配置
    print("\n[3/5] 恢复配置")
    target = os.path.expanduser("~/.openclaw")
    os.makedirs(target, exist_ok=True)

    # 自动探测压缩包内 .openclaw 的层级深度，再决定 --strip-components
    probe = subprocess.run(
        f'tar -tzf "{backup_file}" 2>/dev/null | grep -m1 "\\.openclaw/" || true',
        shell=True, stdout=subprocess.PIPE, text=True
    )
    matched_path = probe.stdout.strip()

    if matched_path:
        # 计算需要剥离的层数：路径中 / 的数量即层数
        strip = matched_path.rstrip("/").count("/")
        print(f"  自动检测层级：{strip}（匹配路径：{matched_path}）")
        restore_cmd = (
            f'tar -xzf "{backup_file}" --strip-components={strip} -C "{target}" '
            f'"*/.openclaw/"'
        )
    else:
        # 降级：直接解压全部到 target
        print("  未找到 .openclaw 路径，尝试全量解压")
        restore_cmd = f'tar -xzf "{backup_file}" -C "{target}"'

    if not run_cmd(restore_cmd, f"解压到 {target}"):
        sys.exit(1)

    # 4. 启动网关
    print("\n[4/5] 启动网关")
    if not run_cmd("openclaw gateway start", "启动网关"):
        sys.exit(1)

    print("\n" + "=" * 55)
    print(f"✅ 全部完成！")
    print(f"   备份来源：{os.path.basename(backup_file)}")
    print(f"   配置目录：{target}")
    print(f"   网关已启动，可以使用。")
    print("=" * 55)

    # 3 秒后自动关闭终端窗口
    print("\n窗口将自动关闭...")
    import time; time.sleep(1)
    subprocess.run(['osascript', '-e', 'tell application "Terminal" to close (every window whose name contains "openclaw-restore")'], capture_output=True)


if __name__ == "__main__":
    main()
