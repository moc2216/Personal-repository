#!/bin/zsh

# 彩色定义（Mac 终端兼容）
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # 重置颜色

clear
echo "${BLUE}🦞 OpenClaw 一键启停控制脚本       ${NC}"
echo ""

# 检查服务运行状态
if pgrep -f "openclaw" > /dev/null; then
    echo "${RED}🔴 检测到 OpenClaw 正在运行${NC}"
    echo "${YELLOW}正在执行关闭流程...${NC}"
    echo ""

    # 执行关闭命令
    openclaw gateway stop
    pkill -f openclaw 2>/dev/null

    echo ""
    echo "${GREEN}✅ 已成功关闭所有 OpenClaw 服务！${NC}"
else
    echo "${GREEN}🟢 检测到 OpenClaw 未运行${NC}"
    echo "${YELLOW}正在执行启动流程...${NC}"
    echo ""

    # 执行启动命令
    openclaw gateway start

    echo ""
    echo "${GREEN}✅ 已成功启动 OpenClaw 服务！${NC}"
fi

sleep 1
osascript -e 'tell application "Terminal" to close (first window whose frontmost is true)'
exit 0